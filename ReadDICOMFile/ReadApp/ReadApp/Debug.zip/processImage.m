function isProcessingDone = processImage(filePath)
I = imread(filePath);
imshow(I);
isProcessingDone = true;
end